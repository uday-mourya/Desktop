<script>
    document.write("<br>My first Program Of JavaScript");
</script>