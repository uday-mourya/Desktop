class Test
{
  public String add()
  {
    //int x=76,y=8;
    return "Kamal";
  }
  
  public static void main(String [] args)
  {
    
   System.out.println("Welcome in main Method");
   System.out.println("Result="+new Test().add()); 
   System.out.println("Main Method End");
  }
}           
