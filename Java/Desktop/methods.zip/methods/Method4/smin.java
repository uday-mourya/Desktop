class Test
{
   public void smin()
   {
    System.out.println("How Many elements You Wants To Entered");
    int a[]=new int [n]
    
   
   } 
  
