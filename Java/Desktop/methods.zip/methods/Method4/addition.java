class Test
{
   public int add(int x,int y)
   {
     return x+y;
   }
  public static void main(String [] args)
  {
    int res =new Test().add(9,4);
    System.out.println("Result = "+res);
   // System.out.println("Result = "+new Tet().add(12,13);
    
  }
  
  
}  
