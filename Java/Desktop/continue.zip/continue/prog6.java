class Test{
   public static void main(String args[])
   {
      for(int i=0; ;)
      {
        System.out.print(i++);
        
        if(i>=10)
        continue;
      }
   }
}
