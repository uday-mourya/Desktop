class Test
{
  public static void main(String args[])
  {
    int i,j;
    
    for(i=1;i<=5;i++)
    {
      if(i==2)
      {
        continue;
      }
        System.out.println(i);
    }
  }
}
