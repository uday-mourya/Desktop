class Test
{
  public static void main(String args[])
  {
    int i=1;
    for(i=1;i<=10;i++)
    {
      if(i<8)
      System.out.println(i);
      break;
    }
  }
}
