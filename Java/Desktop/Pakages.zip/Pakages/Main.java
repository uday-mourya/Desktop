import java.util.Scanner;
import packpojo.Pojo;
import packarea.Area;
class Main
{
    public static void main(String args[])
    {
       Scanner sc=new Scanner(System.in);
       Area ob=new Area();
       Pojo ob1=new Pojo();
       System.out.println("Enter lenght :");
       double l=sc.nextDouble();
       System.out.println("Enter wight :");
       double b=sc.nextDouble();
       System.out.println("Enter haight :");
       double h=sc.nextDouble();
       ob1.setData(l,b);
       ob.areaSquare(ob1);
    }
}
