package packarea;
import packpojo.Pojo;
public class Area
{
    public void areaSquare(Pojo ob1)
    {
        System.out.println("Area is Square :"+ob1.getareaL()*ob1.getareaB());
    }
}

