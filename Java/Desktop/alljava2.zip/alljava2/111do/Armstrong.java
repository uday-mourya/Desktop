import java.util.Scanner;
class Test{
  public static void main(String args[]){
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter any natural number");
    int n=sc.nextInt();
    int n=m;
    int sum=0;
    for(int i=1;i>0;i++)
    {
      for(int j=1
      
      
     )
      {
     
    
      }
    }
 }
}   
