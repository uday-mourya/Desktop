import java.util.Scanner;
class Test{

  public static void main(String args[]){
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter Number");
    int x=sc.nextInt();
    System.out.println("Enter any Power");
    int y=sc.nextInt();
    
       System.out.println(Math.max(x,y));
       System.out.println(Math.min(153,10));
       System.out.println(Math.max(2012,5));
       System.out.println(Math.max(353,3));
    
     
}
}    
