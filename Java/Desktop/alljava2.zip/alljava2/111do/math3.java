import java.util.Scanner;
class Test{

  public static void main(String args[]){
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter Number");
    int x=sc.nextInt();
    System.out.println("Enter any Power");
    int y=sc.nextInt();
    
       System.out.println(Math.IEEEremainder(x,y));
       System.out.println(Math.IEEEremainder(153,10));
       System.out.println(Math.IEEEremainder(2012,5));
       System.out.println(Math.IEEEremainder(353,3));
    
     
}
}    
