import java.util.Scanner;
class Test{

  public static void main(String args[]){
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter Number");
    int x=sc.nextInt();
    
       System.out.println(Math.cbrt(x));
       System.out.println(Math.cbrt(216));
       System.out.println(Math.cbrt(343));
       System.out.println(Math.cbrt(512));
    
     
}
}    
