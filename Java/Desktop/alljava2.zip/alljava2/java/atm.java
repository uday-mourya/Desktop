import java.util.Scanner;

class Atm{
public static void main(String[] args)
{ 

  Scanner vo = new Scanner(System.in);
  System.out.println("Enter Your Name....");
  String a =vo.nextLine();
  
  System.out.println(" --------------------------------------------------------" );
  System.out.println("|\t\t PUNJAB NATIONAL BANK   \t\t|");
  System.out.println("|\t\t----------------------  \t\t|");
  System.out.println("|\t\t\t\t     ATM&Shopping Card  |" );
  System.out.println("|   _____  \t\t\t\t\t\t|" );
  System.out.println("|  |     | \t\t\t\t\t\t|" );
  System.out.println("|  |_____| \t\t\t\t\t\t|" );
  System.out.println("|\t\t 6070 9360 8241 3333 \t\t\t|" );
  System.out.println("|\t\t VALID      VALID \t\t\t|" );
  System.out.println("|\t\t From 01/23 THRU 11/27 \t\t\t|" );
  System.out.println("|    "+a+"\t\t\t\t\t        | ");
  System.out.println("| \t\t\t\t\t\tRUPAY   |" );
  System.out.println("| \t\t\t\t\t\t  DEBIT |" );
  System.out.println(" -------------------------------------------------------" );
}
}
