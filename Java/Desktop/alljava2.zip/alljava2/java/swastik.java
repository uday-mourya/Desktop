class Swastik{
public static void main(String[] args)
{
System.out.println("\t\t\t| \t -------");
System.out.println("\t\t\t| \t|");
System.out.println("\t\t\t| \t|");
System.out.println("\t\t\t| \t|");
System.out.println("\t\t\t-----------------");
System.out.println("\t\t\t  \t| \t|");
System.out.println("\t\t\t  \t| \t|");
System.out.println("\t\t\t  \t| \t|");
System.out.println("\t\t\t--------");

}
}
