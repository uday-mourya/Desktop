class Voterid{
public static void main(String[] args)
{
  System.out.println(" --------------------------------------------------------" );
  System.out.println("|\t\tELECTION COMMISION OF INDIA   \t\t|");
  System.out.println("|\t\t---------------------------   \t\t|");
  System.out.println("| Epic No.  \t\t\t\t\t\t|" );
  System.out.println("| ABC4520436 \t\t\t\t\t\t|" );
  
  System.out.println("|----------- \t\t\t\t\t\t|" );
  System.out.println("||         | \t\t\t\t\t\t|" );
  System.out.println("||         |\tName        : Aayush Awasthi \t\t|" );
  System.out.println("||         |\tFather Name : Sanjay Awasthi\t\t|" );
  System.out.println("||         |\tDOB         : DD/MM/YYYY \t\t|" );
  System.out.println("|----------- \t\t\t\t\t\t|" );
  System.out.println("|\t   Electors Photo Identity Card \t\t|" );
  System.out.println(" ------------------------------------------------------" );
}
}
