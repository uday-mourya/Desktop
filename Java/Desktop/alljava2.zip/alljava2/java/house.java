class House{
	public static void main(String[] args)
{                            
		System.out.println("\t\t\t      ________________");                            
		System.out.println("\t\t\t     /\\    \t     |\t\t");                            
		System.out.println("\t\t\t    /__\\_____________|\t\t");                       
		System.out.println("\t\t\t    |  |    \t     |\t\t");  
		System.out.println("\t\t\t    |  |     ___     |\t\t");  
		System.out.println("\t\t\t    |  |    |   |    |\t\t");  
		System.out.println("\t\t\t    |  |    |   |    |\t\t");  
		System.out.println("\t\t\t    |__|____|___|____|\t\t");  
		                                                    
}
}
