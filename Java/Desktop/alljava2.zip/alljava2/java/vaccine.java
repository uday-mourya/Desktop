class Vaccine{
 public static void main(String [] args){
	  java.util.Scanner sc=new java.util.Scanner(System.in);
	  System.out.println("\t\tEnter Name....");
	  String a = sc.nextLine();
   	  System.out.println("\t\tEnter Date of Birth");
   	  String b = sc.next();
   	  System.out.println("\t\tEnter Gender");
   	  String c = sc.next();
   	  
     System.out.println("\t\t\t\t\t\t\tMINISTRY Of Helth And Wealfare"); 
     System.out.println("\t\t\t\t\t\t\t      Government Of India");
     System.out.println("");
     System.out.println("\t\t\t\t\t\t       Covid-19 Vaccination Certificate");
     System.out.println("\t\t\t\t\tissued in india by Ministry Health & Family Wealfare, Govt of india  ");
     System.out.println("");
     System.out.println("\t\tBeneficiary Details");
     System.out.println("\t\t-------------------");
     System.out.println("\t\tBeneficiary Name          \t\t\t\t\t"+a);
     System.out.println("");
     System.out.println("\t\tDate of Birth(YYYY-MM-DD) \t\t\t\t\t"+b);
     System.out.println("");
     System.out.println("\t\tGender                    \t\t\t\t\t"+c);
     System.out.println("");
     System.out.println("\t\tPassport Number           \t\t\t\t\t8845 0525 5251");
     System.out.println(""); 
     System.out.println("\t\tVaccination Status(# of doses)\t\t\t\t");
     System.out.println("");
     System.out.println("\t\tBeneficiary Refrence ID   \t\t\t\t\t1022325566");
     System.out.println("");
     System.out.println("");
     System.out.println("\t\tVaccination Details");
     System.out.println("\t\t-------------------");
     System.out.println("\t\tVaccine Name             \t\t\t\t\tCOVAXIN");
     System.out.println("");
     System.out.println("\t\tVaccine Type             \t\t\t\t\tcovid-19,inactive virus");
     System.out.println("");
     System.out.println("\t\tManufacture              \t\t\t\t\tBharat BIotech ,India");
     System.out.println("");
     System.out.println("\t\tDose(#)                  \t\t\t\t\t1st\t\t\t2nd");
     System.out.println("");
     System.out.println("\t\tDate of Dose(YYYY-MM-DD)");
     System.out.println("");
     System.out.println("\t\tDate Batch");
     System.out.println("");
     System.out.println("");
     System.out.println("");
     System.out.println("");
     System.out.println("\t\t\t\t\tTogether,India will defeat");
     System.out.println("\t\t\t\t\tCOVID-19");
     System.out.println("");
     System.out.println("\t\t\t\t\t-Prime Minister Narendra Modi");
     System.out.println("\t\t\t_____________________________________________");
     System.out.println("\t\tin-case of anyadverse events,kindly contact the nearest health centre");
     System.out.println("\t\tThis certificate is compliant with WHO-DOCC:VS data dictionary");
 }
 }
