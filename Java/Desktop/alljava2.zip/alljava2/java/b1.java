import java.io.*;
class Break{
	public static void main(String args[])
	{
	  StringBuffer sj = new StringBuffer();
	
	  sb.append("Hello");
	  sb.append("");
	  sb.append("World");
	  String message = sj.toString();
    	  System.out.println(message);	
	}
}
