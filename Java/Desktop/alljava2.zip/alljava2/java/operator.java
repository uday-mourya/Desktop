class Operator{
	public static void main(String[] args)
	
{  
   byte a=5,b=5;
   int A=10,B=10;
   long c=10,d=30;
   double p =85875; 
   char myletter='m',letter='g';
   //short q=854236;
   //int c=a+b;
    System.out.println(myletter+letter);
    //System.out.println(q);
    System.out.println(p);
    System.out.println(A+B);
    System.out.println(a+b);
    System.out.println(c+d);
    System.out.println("SUM="+(a+b));
    System.out.println("SUM="+a+b);
    System.out.println(a+b+ " Is Sum");
    


} 
}
