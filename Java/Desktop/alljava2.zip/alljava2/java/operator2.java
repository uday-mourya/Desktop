class Op{
	public static void main(String[] args)
	
{  byte a=5,b=5;
   byte c=(byte)(a+b);
    System.out.println("SUM="+c);



} 
}
