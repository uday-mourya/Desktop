class Test{
 public static void main(String [] args){
	int a[]=new int [7];
	
	a[0]=0;
	a[1]=1;
	a[2]=2;
	a[3]=3;
	a[4]=4;
	a[5]=5;
	a[6]=6;
	
	System.out.println(a[0]);System.out.println(a[1]);
	System.out.println(a[2]);System.out.println(a[3]);
	System.out.println(a[4]);System.out.println(a[5]);
	System.out.println(a[5]);System.out.println(a[6]);
	
	 
}
} 
