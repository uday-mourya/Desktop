class Test
{
  public static void main(String[]args)
   {
	java.util.Scanner sc=new java.util.Scanner(System.in);
        int a[] ={1,2,3,4,5};
        for(int i=0;i<a.length;i++)
          System.out.println(a[i]);
        // For each Loop; 
          for(int x:a)
            System.out.println(x);
            
         for(String x:a)
            System.out.println(x);
          
}
}          
